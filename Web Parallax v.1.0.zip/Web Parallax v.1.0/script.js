/* Parallax Script | Keegan Hinnigan | 23.06.2020 */

function parallax() {

	var offset = window.pageYOffset;

	const layer1 = document.querySelector('#L1');
	const layer2 = document.querySelector('#L2');
	const layer3 = document.querySelector('#L3');
	const layer4 = document.querySelector('#L4');
	const layer5 = document.querySelector('#L5');
	const layer6 = document.querySelector('#L6');
	const layer7 = document.querySelector('#L7');
	const layer8 = document.querySelector('#L8');
	const layer9 = document.querySelector('#L9');

	var coord1 = '0% ' + ( + (offset / 1.1) + 'px');
	var coord2 = '0% ' + ( + (offset / 1.2) + 'px');
	var coord3 = '0% ' + ( + (offset / 1.3) + 'px');
	var coord4 = '0% ' + ( + (offset / 1.4) + 'px');
	var coord5 = '0% ' + ( + (offset / 0.8) + 'px'); // Logo / Text Layer
	var coord6 = '0% ' + ( + (offset / 1.6) + 'px');
	var coord7 = '0% ' + ( + (offset / 1.7) + 'px');
	var coord8 = '0% ' + ( + (offset / 1.8) + 'px');
	var coord9 = '0% ' + ( + (offset / 1.9) + 'px');

	layer1.style.backgroundPosition = coord1;
	layer2.style.backgroundPosition = coord2;
	layer3.style.backgroundPosition = coord3;
	layer4.style.backgroundPosition = coord4;
	layer5.style.backgroundPosition = coord5;
	layer6.style.backgroundPosition = coord6;
	layer7.style.backgroundPosition = coord7;
	layer8.style.backgroundPosition = coord8;
	layer9.style.backgroundPosition = coord9;    	
}

window.addEventListener('scroll', parallax); // Updates Layer Positions When Mouse Scrolled.
window.addEventListener('DOMContentLoaded', parallax); // Updates Layer Positions When Page Loaded.

/* Copyright Notice */
var date = new Date();
document.getElementById("footer-note").innerHTML = "Copyright &copy; " + date.getFullYear() + " Keegan Hinnigan. All Rights Reserved";